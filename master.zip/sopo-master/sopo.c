#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include "spa.h"

void print_usage()
{
    printf("Usage: sopo [-k value]\n");
    printf("-y to set observer local year,         0 ~ 6000,               default local time\n");
    printf("-m to set observer local month,        1 ~ 12,                 default local time\n");
    printf("-d to set observer local day,          1 ~ 31,                 default local time\n");
    printf("-H to set observer local hour,         0 ~ 23,                 default local time\n");
    printf("-M to set observer local minute,       0 ~ 59,                 default local time\n");
    printf("-S to set observer local second,       0 ~ 59,                 default local time\n");
    printf("-z to set observer time zone,        -18 ~ 18,                 default 0\n");
    printf("-u to set (UTC - UT),                 -1 ~ 1        seconds,   default 0\n");
    printf("-t to set (TAI - UTC + rest),      -8000 ~ 8000     seconds,   default 68\n");
    printf("-l to set observer longitude,       -180 ~ 180      degrees,   default 0\n");
    printf("-b to set observer latitude,         -90 ~ 90       degrees,   default 0\n");
    printf("-e to set observer elevation,   -6500000 ~ infinity meters,    default 0\n");
    printf("-p to set annual mean pressure,        0 ~ 5000     millibars, default 820\n");
    printf("-T to set annual mean temperature,  -273 ~ 6000     degrees C, default 15\n");
    printf("-s to set surface slope,            -360 ~ 360      degrees,   default 0\n");
    printf("-r to set surface azimuth rotation, -360 ~ 360      degrees,   default 0\n");
    printf("-a to set atmospheric refraction,     -5 ~ 5        degrees,   default 0.5667\n");
    printf("-h to print this help information\n");
}

void init_spa_data(spa_data *spa, int argc, char *argv[])
{
    struct tm *tm_ptr;
    time_t tnow;
    int opt;

    tnow = time(NULL);
    tm_ptr = localtime(&tnow);
    // for leap seconds
    if (tm_ptr->tm_sec > 59) tm_ptr->tm_sec = 59;

    // set default values
    spa->year           = tm_ptr->tm_year + 1900;
    spa->month          = tm_ptr->tm_mon + 1;
    spa->day            = tm_ptr->tm_mday;
    spa->hour           = tm_ptr->tm_hour;
    spa->minute         = tm_ptr->tm_min;
    spa->second         = tm_ptr->tm_sec;
    spa->delta_ut1      = 0;
    spa->delta_t        = 68;
    spa->pressure       = 820;
    spa->temperature    = 15;
    spa->slope          = 0;
    spa->azm_rotation   = 0;
    spa->atmos_refract  = 0.5667;
    spa->function       = SPA_ALL;

    while((opt = getopt(argc, argv, "y:m:d:H:M:S:z:u:t:l:b:e:p:T:s:r:a:h")) != -1) {
        switch(opt) {
        case 'y':
            spa->year = atoi(optarg);
            break;
        case 'm':
            spa->month = atoi(optarg);
            break;
        case 'd':
            spa->day = atoi(optarg);
            break;
        case 'H':
            spa->hour = atoi(optarg);
            break;
        case 'M':
            spa->minute = atoi(optarg);
            break;
        case 'S':
            spa->second = atof(optarg);
            break;
        case 'z':
            spa->timezone = atof(optarg);
            break;
        case 'u':
            spa->delta_ut1 = atof(optarg);
            break;
        case 't':
            spa->delta_t = atof(optarg);
            break;
        case 'l':
            spa->longitude = atof(optarg);
            break;
        case 'b':
            spa->latitude = atof(optarg);
            break;
        case 'e':
            spa->elevation = atof(optarg);
            break;
        case 'p':
            spa->pressure = atof(optarg);
            break;
        case 'T':
            spa->temperature = atof(optarg);
            break;
        case 's':
            spa->slope = atof(optarg);
            break;
        case 'r':
            spa->azm_rotation = atof(optarg);
            break;
        case 'a':
            spa->atmos_refract = atof(optarg);
            break;
        case 'h':
        case '?':
            print_usage();
            exit(0);
            break;
        }
    }
}

void print_result(const spa_data *spa)
{
    double min, sec;
    //display the results inside the SPA structure in JSON format
    printf("{");
    printf("\"dtz\":\"%04d-%02d-%02d %02d:%02d:%02d %+03d\",",
        spa->year, spa->month, spa->day, spa->hour, spa->minute, (int)(spa->second), (int)(spa->timezone));
    printf("\"lon\":%.04lf,", spa->longitude);
    printf("\"lat\":%.04lf,", spa->latitude);
    printf("\"alt\":%.01lf,", spa->elevation);
    printf("\"azi\":%.04lf,", spa->azimuth);
    printf("\"zen\":%.04lf,", spa->zenith);
    printf("\"inc\":%.04lf,", spa->incidence);
    min = 60.0*(spa->sunrise - (int)(spa->sunrise));
    sec = 60.0*(min - (int)min);
    printf("\"ris\":\"%02d:%02d:%02d\",", (int)(spa->sunrise), (int)min, (int)sec);
    min = 60.0*(spa->suntransit - (int)(spa->suntransit));
    sec = 60.0*(min - (int)min);
    printf("\"mid\":\"%02d:%02d:%02d\",", (int)(spa->suntransit), (int)min, (int)sec);
    min = 60.0*(spa->sunset - (int)(spa->sunset));
    sec = 60.0*(min - (int)min);
    printf("\"set\":\"%02d:%02d:%02d\"", (int)(spa->sunset), (int)min, (int)sec);
    printf("}\n");
}

int main (int argc, char *argv[])
{
    spa_data spa = {0};  //declare the SPA structure
    int result;

    //enter required input values into SPA structure
    init_spa_data(&spa, argc, argv);

    //call the SPA calculate function and pass the SPA structure
    result = spa_calculate(&spa);

    if (result == 0) { //check for SPA errors
        print_result(&spa);
    } else {
        printf("Sopo exits with ERROR code: %d\n", result);
        print_usage();
    };

    return 0;
}
