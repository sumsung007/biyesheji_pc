# sopo
Solar position calculator with SPA.

# Usage
    sopo [-k value]
    -y to set observer local year,         0 ~ 6000,               default local time
    -m to set observer local month,        1 ~ 12,                 default local time
    -d to set observer local day,          1 ~ 31,                 default local time
    -H to set observer local hour,         0 ~ 23,                 default local time
    -M to set observer local minute,       0 ~ 59,                 default local time
    -S to set observer local second,       0 ~ 59,                 default local time
    -z to set observer time zone,        -18 ~ 18,                 default 0
    -u to set (UTC - UT),                 -1 ~ 1        seconds,   default 0
    -t to set (TAI - UTC + rest),      -8000 ~ 8000     seconds,   default 68
    -l to set observer longitude,       -180 ~ 180      degrees,   default 0
    -b to set observer latitude,         -90 ~ 90       degrees,   default 0
    -e to set observer elevation,   -6500000 ~ infinity meters,    default 0
    -p to set annual mean pressure,        0 ~ 5000     millibars, default 820
    -T to set annual mean temperature,  -273 ~ 6000     degrees C, default 15
    -s to set surface slope,            -360 ~ 360      degrees,   default 0
    -r to set surface azimuth rotation, -360 ~ 360      degrees,   default 0
    -a to set atmospheric refraction,     -5 ~ 5        degrees,   default 0.5667
    -h to print this help information

#Example
    sopo -y 2015 -m 8 -d 18 -H 16 -M 16 -S 30 -z 8 -u 0 -t 68 -l 120.123 -b 30.123 -e 200

Outputs:

    {
        "dtz":"2015-08-18 16:16:30 +08", // local date time and timezone
        "lon":120.1230,                  // observer longitude
        "lat":30.1230,                   // observer latitude
        "alt":200.0,                     // observer altitude
        "azi":268.4837,                  // sun azimuth
        "zen":60.4291,                   // sun zenith
        "inc":60.4291,                   // sun incidence
        "ris":"05:28:36",                // sunrise time
        "mid":"12:03:29",                // sun transit time
        "set":"18:38:31"                 // sunset time
    }

